# Font Attribution

This folder contains the following fonts:

- Montserrat (Regular, Medium, Bold)
- Playfair Display (Regular, Bold)

These fonts are being used under the Open Font License.

## Montserrat

Copyright 2011 The Montserrat Project Authors (https://github.com/JulietaUla/Montserrat)

This Font Software is licensed under the SIL Open Font License, Version 1.1.

## Playfair Display

Copyright 2017 The Playfair Display Project Authors (https://github.com/clauseggers/Playfair-Display)

This Font Software is licensed under the SIL Open Font License, Version 1.1.